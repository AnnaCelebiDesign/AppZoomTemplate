window.__imported__ = window.__imported__ || {};
window.__imported__["AppZoomTemplate/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "61BD1F56-489A-46BF-ABD7-90828EF789A0",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "D89CFB30-DE85-462C-8CD8-355118A6CB5C",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/Layer-YourApp-D89CFB30-DE85-462C-8CD8-355118A6CB5C.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "kind" : "group",
        "metadata" : {
          "opacity" : 1
        },
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "YourApp"
      },
      {
        "maskFrame" : null,
        "id" : "06F5F6CE-AEFE-4E45-9121-1B6BE8CD0F48",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "DEF1EDBA-AEF2-461C-97AF-A09DBE01FB36",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "C32A30C4-45C6-409D-A38A-8D6E922A10D4",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Your_App-C32A30C4-45C6-409D-A38A-8D6E922A10D4.png",
                  "frame" : {
                    "y" : 749,
                    "x" : 392,
                    "width" : 142,
                    "height" : 175
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 749,
                  "x" : 392,
                  "width" : 142,
                  "height" : 175
                },
                "name" : "Your_App"
              }
            ],
            "imageType" : "png",
            "kind" : "group",
            "metadata" : {
              "opacity" : 1
            },
            "layerFrame" : {
              "y" : 749,
              "x" : 392,
              "width" : 142,
              "height" : 175
            },
            "name" : "appIcon"
          },
          {
            "maskFrame" : null,
            "id" : "F6D457CF-B813-4B14-BD23-D3CB2E82F645",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "9C3498D7-0F89-4233-BBA4-C7A893DC8FBB",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iMessage-9C3498D7-0F89-4233-BBA4-C7A893DC8FBB.png",
                  "frame" : {
                    "y" : 45,
                    "x" : 37,
                    "width" : 153,
                    "height" : 178
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 45,
                  "x" : 37,
                  "width" : 153,
                  "height" : 178
                },
                "name" : "iMessage"
              },
              {
                "maskFrame" : null,
                "id" : "F93FBD50-1785-489D-887C-625F779D5A5A",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Calendar-F93FBD50-1785-489D-887C-625F779D5A5A.png",
                  "frame" : {
                    "y" : 45,
                    "x" : 217,
                    "width" : 139,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 45,
                  "x" : 217,
                  "width" : 139,
                  "height" : 174
                },
                "name" : "Calendar"
              },
              {
                "maskFrame" : null,
                "id" : "8BD2F758-363F-4FC2-8C09-7A2EEB42119A",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Photos-8BD2F758-363F-4FC2-8C09-7A2EEB42119A.png",
                  "frame" : {
                    "y" : 46,
                    "x" : 402,
                    "width" : 120,
                    "height" : 173
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 46,
                  "x" : 402,
                  "width" : 120,
                  "height" : 173
                },
                "name" : "Photos"
              },
              {
                "maskFrame" : null,
                "id" : "B9F63113-7FA6-4FA0-A438-BF26B2C4ED0D",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Camera-B9F63113-7FA6-4FA0-A438-BF26B2C4ED0D.png",
                  "frame" : {
                    "y" : 45,
                    "x" : 572,
                    "width" : 127,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 45,
                  "x" : 572,
                  "width" : 127,
                  "height" : 174
                },
                "name" : "Camera"
              },
              {
                "maskFrame" : null,
                "id" : "9C258634-7C01-4577-84ED-4836EA266482",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Weather-9C258634-7C01-4577-84ED-4836EA266482.png",
                  "frame" : {
                    "y" : 221,
                    "x" : 48,
                    "width" : 131,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 221,
                  "x" : 48,
                  "width" : 131,
                  "height" : 174
                },
                "name" : "Weather"
              },
              {
                "maskFrame" : null,
                "id" : "231F8EB0-DA4F-47EE-BC66-E49D1D753332",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Clock-231F8EB0-DA4F-47EE-BC66-E49D1D753332.png",
                  "frame" : {
                    "y" : 221,
                    "x" : 228,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 221,
                  "x" : 228,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "Clock"
              },
              {
                "maskFrame" : null,
                "id" : "1138C18D-2998-4177-8265-A03FC7586E48",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Maps-1138C18D-2998-4177-8265-A03FC7586E48.png",
                  "frame" : {
                    "y" : 221,
                    "x" : 402,
                    "width" : 120,
                    "height" : 175
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 221,
                  "x" : 402,
                  "width" : 120,
                  "height" : 175
                },
                "name" : "Maps"
              },
              {
                "maskFrame" : null,
                "id" : "B75BDB00-71C2-4317-82B1-FCAB47B2FF41",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Videos-B75BDB00-71C2-4317-82B1-FCAB47B2FF41.png",
                  "frame" : {
                    "y" : 221,
                    "x" : 576,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 221,
                  "x" : 576,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "Videos"
              },
              {
                "maskFrame" : null,
                "id" : "03E4F3E7-02A2-453D-849B-BCB50C0D109B",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Notes-03E4F3E7-02A2-453D-849B-BCB50C0D109B.png",
                  "frame" : {
                    "y" : 397,
                    "x" : 228,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 397,
                  "x" : 228,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "Notes"
              },
              {
                "maskFrame" : null,
                "id" : "C86E7E3D-0386-45E1-A8C1-CCC9DF513D24",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Reminders-C86E7E3D-0386-45E1-A8C1-CCC9DF513D24.png",
                  "frame" : {
                    "y" : 397,
                    "x" : 382,
                    "width" : 160,
                    "height" : 175
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 397,
                  "x" : 382,
                  "width" : 160,
                  "height" : 175
                },
                "name" : "Reminders"
              },
              {
                "maskFrame" : null,
                "id" : "0D0E46FA-D306-4389-BE42-1AFC89D130BA",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Stocks-0D0E46FA-D306-4389-BE42-1AFC89D130BA.png",
                  "frame" : {
                    "y" : 397,
                    "x" : 576,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 397,
                  "x" : 576,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "Stocks"
              },
              {
                "maskFrame" : null,
                "id" : "161B5FEB-7180-41EE-91DE-04C2E70BB2B6",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Wallet-161B5FEB-7180-41EE-91DE-04C2E70BB2B6.png",
                  "frame" : {
                    "y" : 397,
                    "x" : 54,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 397,
                  "x" : 54,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "Wallet"
              },
              {
                "maskFrame" : null,
                "id" : "EC72135C-6C3B-4380-AB72-85355ADEB94F",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iBooks-EC72135C-6C3B-4380-AB72-85355ADEB94F.png",
                  "frame" : {
                    "y" : 573,
                    "x" : 402,
                    "width" : 120,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 573,
                  "x" : 402,
                  "width" : 120,
                  "height" : 174
                },
                "name" : "iBooks"
              },
              {
                "maskFrame" : null,
                "id" : "FCCD2344-C624-481F-A69D-B98271A0B911",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-iTunes_Store-FCCD2344-C624-481F-A69D-B98271A0B911.png",
                  "frame" : {
                    "y" : 573,
                    "x" : 25,
                    "width" : 181,
                    "height" : 174
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 573,
                  "x" : 25,
                  "width" : 181,
                  "height" : 174
                },
                "name" : "iTunes_Store"
              },
              {
                "maskFrame" : null,
                "id" : "88293D1D-CC82-4846-A934-3454266413F9",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-News-88293D1D-CC82-4846-A934-3454266413F9.png",
                  "frame" : {
                    "y" : 573,
                    "x" : 576,
                    "width" : 120,
                    "height" : 173
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 573,
                  "x" : 576,
                  "width" : 120,
                  "height" : 173
                },
                "name" : "News"
              },
              {
                "maskFrame" : null,
                "id" : "268DD464-2DD4-48A1-A29C-4E0BC6605444",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-App_Store-268DD464-2DD4-48A1-A29C-4E0BC6605444.png",
                  "frame" : {
                    "y" : 573,
                    "x" : 212,
                    "width" : 151,
                    "height" : 176
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 573,
                  "x" : 212,
                  "width" : 151,
                  "height" : 176
                },
                "name" : "App_Store"
              },
              {
                "maskFrame" : null,
                "id" : "7955A635-B2BA-4A29-BF20-11B9A3A38B2C",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Settings-7955A635-B2BA-4A29-BF20-11B9A3A38B2C.png",
                  "frame" : {
                    "y" : 749,
                    "x" : 222,
                    "width" : 132,
                    "height" : 177
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 749,
                  "x" : 222,
                  "width" : 132,
                  "height" : 177
                },
                "name" : "Settings"
              },
              {
                "maskFrame" : null,
                "id" : "865E2D29-AC97-461F-B8D9-B6B11B57906F",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Health-865E2D29-AC97-461F-B8D9-B6B11B57906F.png",
                  "frame" : {
                    "y" : 749,
                    "x" : 54,
                    "width" : 120,
                    "height" : 173
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 749,
                  "x" : 54,
                  "width" : 120,
                  "height" : 173
                },
                "name" : "Health"
              },
              {
                "maskFrame" : null,
                "id" : "6A1CAD5F-56C8-448A-852A-8D9626D9F821",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Music-6A1CAD5F-56C8-448A-852A-8D9626D9F821.png",
                  "frame" : {
                    "y" : 1170,
                    "x" : 576,
                    "width" : 120,
                    "height" : 164
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 1170,
                  "x" : 576,
                  "width" : 120,
                  "height" : 164
                },
                "name" : "Music"
              },
              {
                "maskFrame" : null,
                "id" : "1BB325AA-72B8-466C-BB18-E8F61140F6BB",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Mail-1BB325AA-72B8-466C-BB18-E8F61140F6BB.png",
                  "frame" : {
                    "y" : 1170,
                    "x" : 402,
                    "width" : 120,
                    "height" : 153
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 1170,
                  "x" : 402,
                  "width" : 120,
                  "height" : 153
                },
                "name" : "Mail"
              },
              {
                "maskFrame" : null,
                "id" : "EFD28DBD-3A40-48A5-941A-539FE861E784",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Phone-EFD28DBD-3A40-48A5-941A-539FE861E784.png",
                  "frame" : {
                    "y" : 1170,
                    "x" : 54,
                    "width" : 120,
                    "height" : 153
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 1170,
                  "x" : 54,
                  "width" : 120,
                  "height" : 153
                },
                "name" : "Phone"
              },
              {
                "maskFrame" : null,
                "id" : "2AD82CAF-755C-4170-A9E6-0F1FFFB29899",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Safari-2AD82CAF-755C-4170-A9E6-0F1FFFB29899.png",
                  "frame" : {
                    "y" : 1170,
                    "x" : 228,
                    "width" : 120,
                    "height" : 164
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 1170,
                  "x" : 228,
                  "width" : 120,
                  "height" : 164
                },
                "name" : "Safari"
              }
            ],
            "imageType" : "png",
            "kind" : "group",
            "metadata" : {
              "opacity" : 1
            },
            "layerFrame" : {
              "y" : 45,
              "x" : 25,
              "width" : 674,
              "height" : 1289
            },
            "name" : "defaultIcons"
          },
          {
            "maskFrame" : null,
            "id" : "197F697D-A69B-4BB9-8031-E196790396F2",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "38886ABD-782A-4433-B58B-54E83101ED64",
                "visible" : true,
                "children" : [
                  {
                    "maskFrame" : null,
                    "id" : "086EC371-B287-4D7D-A9E7-8EA71F090652",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Battery_Icon-086EC371-B287-4D7D-A9E7-8EA71F090652.png",
                      "frame" : {
                        "y" : 11,
                        "x" : 690,
                        "width" : 49,
                        "height" : 19
                      }
                    },
                    "imageType" : "png",
                    "kind" : "group",
                    "metadata" : {
                      "opacity" : 1
                    },
                    "layerFrame" : {
                      "y" : 11,
                      "x" : 690,
                      "width" : 49,
                      "height" : 19
                    },
                    "name" : "Battery_Icon"
                  },
                  {
                    "maskFrame" : null,
                    "id" : "8D5E4A00-4F2B-428B-93DB-AE062875D45F",
                    "visible" : true,
                    "children" : [

                    ],
                    "image" : {
                      "path" : "images\/Layer-Signal-8D5E4A00-4F2B-428B-93DB-AE062875D45F.png",
                      "frame" : {
                        "y" : 15,
                        "x" : 13,
                        "width" : 67,
                        "height" : 11
                      }
                    },
                    "imageType" : "png",
                    "kind" : "group",
                    "metadata" : {
                      "opacity" : 1
                    },
                    "layerFrame" : {
                      "y" : 15,
                      "x" : 13,
                      "width" : 67,
                      "height" : 11
                    },
                    "name" : "Signal"
                  }
                ],
                "image" : {
                  "path" : "images\/Layer-Status_Bar__White_-38886ABD-782A-4433-B58B-54E83101ED64.png",
                  "frame" : {
                    "y" : 10,
                    "x" : 13,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 10,
                  "x" : 13,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "Status_Bar__White_"
              },
              {
                "maskFrame" : null,
                "id" : "D5D75364-6538-4C55-82FF-C05F0A53B674",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/Layer-Pagination-D5D75364-6538-4C55-82FF-C05F0A53B674.png",
                  "frame" : {
                    "y" : 1121,
                    "x" : 336,
                    "width" : 78,
                    "height" : 16
                  }
                },
                "imageType" : "png",
                "kind" : "group",
                "metadata" : {
                  "opacity" : 1
                },
                "layerFrame" : {
                  "y" : 1121,
                  "x" : 336,
                  "width" : 78,
                  "height" : 16
                },
                "name" : "Pagination"
              }
            ],
            "image" : {
              "path" : "images\/Layer-background-197F697D-A69B-4BB9-8031-E196790396F2.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 750,
                "height" : 1334
              }
            },
            "imageType" : "png",
            "kind" : "group",
            "metadata" : {
              "opacity" : 1
            },
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 750,
              "height" : 1334
            },
            "name" : "background"
          }
        ],
        "imageType" : "png",
        "kind" : "group",
        "metadata" : {
          "opacity" : 1
        },
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "Screen"
      }
    ],
    "imageType" : "png",
    "kind" : "artboard",
    "metadata" : {

    },
    "layerFrame" : {
      "y" : -123,
      "x" : 517,
      "width" : 750,
      "height" : 1334
    },
    "name" : "iPhone_6"
  }
]